/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_301(unsigned *p)
{
    *p = 2421743983U;
}

unsigned addval_130(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_276(unsigned x)
{
    return x + 2425510095U;
}

unsigned addval_336(unsigned x)
{
    return x + 2791424856U;
}

unsigned addval_215(unsigned x)
{
    return x + 2425394264U;
}

void setval_135(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_199()
{
    return 3251079496U;
}

unsigned addval_122(unsigned x)
{
    return x + 3284634440U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_216(unsigned *p)
{
    *p = 2425411209U;
}

void setval_476(unsigned *p)
{
    *p = 3286272456U;
}

void setval_417(unsigned *p)
{
    *p = 3677929864U;
}

unsigned addval_136(unsigned x)
{
    return x + 3348158089U;
}

unsigned addval_105(unsigned x)
{
    return x + 3378561417U;
}

unsigned addval_200(unsigned x)
{
    return x + 3397991177U;
}

unsigned addval_465(unsigned x)
{
    return x + 3526934985U;
}

unsigned addval_212(unsigned x)
{
    return x + 2428602704U;
}

unsigned getval_355()
{
    return 2430634314U;
}

void setval_368(unsigned *p)
{
    *p = 2447411528U;
}

unsigned addval_228(unsigned x)
{
    return x + 3372275337U;
}

void setval_151(unsigned *p)
{
    *p = 3286272328U;
}

void setval_169(unsigned *p)
{
    *p = 3682912905U;
}

unsigned addval_443(unsigned x)
{
    return x + 3676886665U;
}

unsigned addval_398(unsigned x)
{
    return x + 3685013129U;
}

void setval_119(unsigned *p)
{
    *p = 3246996019U;
}

unsigned getval_394()
{
    return 2495711627U;
}

unsigned addval_450(unsigned x)
{
    return x + 2430632264U;
}

unsigned addval_159(unsigned x)
{
    return x + 3529558665U;
}

void setval_436(unsigned *p)
{
    *p = 2430634312U;
}

unsigned addval_315(unsigned x)
{
    return x + 3286272360U;
}

void setval_180(unsigned *p)
{
    *p = 3348152713U;
}

unsigned addval_295(unsigned x)
{
    return x + 2425408201U;
}

unsigned getval_272()
{
    return 3225998985U;
}

unsigned addval_284(unsigned x)
{
    return x + 2425471369U;
}

void setval_290(unsigned *p)
{
    *p = 3398163631U;
}

unsigned addval_325(unsigned x)
{
    return x + 3286272320U;
}

void setval_236(unsigned *p)
{
    *p = 3224950409U;
}

unsigned getval_116()
{
    return 3524843145U;
}

unsigned addval_474(unsigned x)
{
    return x + 3677932171U;
}

unsigned getval_249()
{
    return 3281046145U;
}

unsigned addval_285(unsigned x)
{
    return x + 3531131529U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
